package com.eko.mvp_test.login.model.view.presenter.model

class UserInfoModel {
    var nickname:String =""
    var age: Int=0
}